//import { AppRegistry } from 'react-native';
//import App from './App';

import {
	Navigation
} from 'react-native-navigation';

import SelectExerciseScreen from './screens/select-exercise';

Navigation.registerComponent('transspeech.SelectExercise', () => SelectExerciseScreen);

/*
Navigation.events().registerAppLaunchedListener(() => {
	Navigation.setRoot({
		root: {
			bottomTabs: {
				children: [
					{
						component: {
							name: 'transspeech.SelectExercise',
							passProps: {
								text: 'Select Exercises',
							},
							options: {
								bottomTab: {
									icon: require('./assets/icon-settings.png'),
									title: 'Select Exercises',
								},
							},
						},
					},
				],
			},
		},
	});
});
*/

Navigation.events().registerAppLaunchedListener(() => {
	Navigation.setRoot({
		root: {
			bottomTabs: {
				children: [{
					stack: {
						children: [{
							component: {
								name: 'transspeech.SelectExercise',
							}
						}],
						options: {
							bottomTab: {
								title: 'Exercises',
								icon: require('./assets/icon-exercises2.png'),
							}
						}
					}
					/*
					 *component: {
					 *        name: 'transspeech.SelectExercise',
					 *        options: {
					 *                bottomTab: {
					 *                        title: 'Exercises',
					 *                        icon: require('./assets/icon-exercises2.png'),
					 *                },
					 *        },
					 *},
					 */
				},
				{
					component: {
						name: 'transspeech.SelectExercise',
						options: {
							bottomTab: {
								title: 'History',
								icon: require('./assets/icon-chart.png'),
							},
						},
					},
				},
				{
					component: {
						name: 'transspeech.SelectExercise',
						options: {
							bottomTab: {
								title: 'Settings',
								icon: require('./assets/icon-settings.png'),
							},
						},
					},
				},]
			}
		}
	});
});

//AppRegistry.registerComponent('TransSpeech', () => App);
