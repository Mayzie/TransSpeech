import React, { Component } from 'react';

import {
	StyleSheet,
	View,
	Text,
	FlatList,
	Button,
} from 'react-native';

import {
	CheckBox,
} from '../components/checkbox';

/*
 *import {
 *        Button,
 *} from '../components/button';
 */

import {
	exercises,
} from '../config.exercises';

export default class SelectExerciseScreen extends Component {
	constructor(props) {
		super(props);

		this.state = {
			selected: new Array(exercises.length),
		}

		this.state.selected.fill(true);
	}

	onItemCheckChange = (item, checked) => {
		//console.warn(checked + " " + item.title);
		let selected = this.state.selected;

		selected[item.position] = checked ? checked : undefined;

		this.setState({
			selected,
		});
	}

	onStartPress = () => {
		console.warn(this.state.selected);
	}

	renderItem = ({item}) => {
		let checked = this.state.selected[item.position];

		return (
			<View>
			<CheckBox
				checked={ checked ? true : false }
				title={ item.title + ' (' + item.minReps + ')'}
				onCheckedChange={ (isChecked) => this.onItemCheckChange(item, isChecked) }
				fontSize={ 24 }
			/>
				<Button
					title='Start Exercises'
					onPress={ this.onStartPress }
					backgroundColor='#0000ff'
				/>
			</View>
		);
	}

	render() {
		return (
			<View style={ style.rootStyle }>
				<FlatList
					style={ style.listStyle }
					data={ exercises }
					renderItem={ this.renderItem }
				/>
				<Button
					title='Start Exercises'
					onPress={ this.onStartPress }
					backgroundColor='#0000ff'
				/>
			</View>
		);
	}
}

const style = StyleSheet.create({
	rootStyle: {
		flex: 1,
		flexDirection: 'column',
		paddingLeft: 30,
		paddingRight: 30,
	},
	listStyle: {
		flex: 1,
	},
});
