const sobPhrases = [
	'Oh no',
	'Only one',
	'Everyone', 
	'Even now',
	'All alone',
	'On my own',
	'On my mind',
	'I\'m leaving',
	'In the rain',
	'Over the moon',
	'Early morning',
	'Incy Wincy Spider',
	'Inkle Inkle Little Star',
]

export const exercises = [
	{
		position: 0,
		key: 'mhmm',
		title: 'M-hmmm\'s',
		text: 'M-hmmm',
		minReps: 10,
	},
	{
		position: 1,
		key: 'sob',
		title: 'Sobs',
		text: 'ng (sob)',
		minReps: 10,
	},
	{
		position: 2,
		key: 'sob-phrase',
		title: 'Sob Phrases',
		text: [],
		onNext: (textArray) => {
			textArray.pop();

			// ToDo: Store new array.
		},
		onEmpty: () => {
			// ToDo: Store new array.

			return sobPhrases.slice();
		},
		minReps: 4,
	},
	{
		position: 3,
		key: 'siren',
		title: 'Sirens',
		text: 'Siren',
		minReps: 4,
	},
	{
		position: 4,
		key: 'siren-asc',
		title: 'Sirens (Ascending)',
		text: 'Siren (Ascending)',
		minReps: 4,
	},
	{
		position: 5,
		key: 'siren-desc',
		title: 'Sirens (Descending)',
		text: 'Siren (Descending)',
		minReps: 4,
	},
];

